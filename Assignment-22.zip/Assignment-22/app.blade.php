<!-- resources/views/layouts/app.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>X-Shop</title>
    <!-- Include your CSS and JS files here -->
</head>
<body>
    <nav>
        <!-- Navigation links here -->
    </nav>
    <div class="container">
        @yield('content')
    </div>
</body>
</html>
